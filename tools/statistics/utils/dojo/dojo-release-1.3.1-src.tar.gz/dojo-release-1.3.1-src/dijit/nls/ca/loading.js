({
	loadingState: "S'està carregant...",
	errorState: "Ens sap greu. S'ha produït un error."
})

