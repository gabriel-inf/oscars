({
	buttonOk: "OK",
	buttonCancel: "Annuleren",
	buttonSave: "Opslaan",
	itemClose: "Sluiten"
})
