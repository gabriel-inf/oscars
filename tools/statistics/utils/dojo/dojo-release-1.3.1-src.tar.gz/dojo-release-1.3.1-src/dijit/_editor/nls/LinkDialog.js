({
	createLinkTitle: "Link Properties",
	insertImageTitle: "Image Properties",
	url: "URL:",
	text: "Description:",
	set: "Set"
})
