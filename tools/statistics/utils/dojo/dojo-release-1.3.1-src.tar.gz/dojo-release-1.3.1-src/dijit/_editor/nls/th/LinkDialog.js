({
	createLinkTitle: "คุณสมบัติลิงก์",
	insertImageTitle: "คุณสมบัติอิมเมจ",
	url: "URL:",
	text: "รายละเอียด",
	set: "ตั้งค่า"
})

