({
	createLinkTitle: "Länkegenskaper",
	insertImageTitle: "Bildegenskaper",
	url: "URL-adress:",
	text: "Beskrivning:",
	set: "Ange"
})
