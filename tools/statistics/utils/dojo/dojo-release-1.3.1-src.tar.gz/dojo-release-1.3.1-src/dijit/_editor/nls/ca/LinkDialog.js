({
	createLinkTitle: "Propietats de l'enllaç",
	insertImageTitle: "Propietats de la imatge",
	url: "URL:",
	text: "Descripció:",
	set: "Defineix"
})

