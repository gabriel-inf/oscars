({
	createLinkTitle: "Свойства ссылки",
	insertImageTitle: "Свойства изображения",
	url: "URL:",
	text: "Описание:",
	set: "Задать"
})
