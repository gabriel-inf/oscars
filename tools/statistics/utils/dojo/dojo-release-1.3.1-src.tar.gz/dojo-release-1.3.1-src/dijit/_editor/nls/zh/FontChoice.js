({
	fontSize: "大小",
	fontName: "字体",
	formatBlock: "格式",

	serif: "有衬线",
	"sans-serif": "无衬线",
	monospace: "等宽字体",
	cursive: "草书",
	fantasy: "虚线",

	p: "段落",
	h1: "标题",
	h2: "子标题",
	h3: "二级子标题",
	pre: "预设有格式的",

	1: "XXS 号",
	2: "XS 号",
	3: "S 号",
	4: "M 号",
	5: "L 号",
	6: "XL 号",
	7: "XXL 号"
})